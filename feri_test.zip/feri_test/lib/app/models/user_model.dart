class UserModel {
  String? uid;
  String? email;
  String? firstName;
  String? username;
  String? telepon;
  String? photoURL;

  UserModel({
    this.uid,
    this.email,
    this.firstName,
    this.username,
    this.telepon,
    this.photoURL,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'],
      email: map['email'],
      firstName: map['firstName'],
      username: map['username'],
      telepon: map['telepon'],
      photoURL: map['photoURL'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'firstName': firstName,
      'username': username,
      'telepon': telepon,
      'photoURL': photoURL,
    };
  }
}
