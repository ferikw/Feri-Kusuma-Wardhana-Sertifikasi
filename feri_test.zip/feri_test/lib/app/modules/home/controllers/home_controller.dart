// ignore_for_file: unused_import

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class HomeController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Stream<QuerySnapshot> getItems() {
    return _firestore.collection('items').snapshots();
  }

  Future<void> addItem(String name, double price, int year, String description,
      File image) async {
    String imageUrl = await _uploadImage(image);
    await _firestore.collection('items').add({
      'name': name,
      'price': price,
      'year': year,
      'description': description,
      'image': imageUrl,
    });
  }

  Future<void> updateItem(String id, String name, double price, int year,
      String description, File? image) async {
    String? imageUrl;
    if (image != null) {
      imageUrl = await _uploadImage(image);
    }
    await _firestore.collection('items').doc(id).update({
      'name': name,
      'price': price,
      'year': year,
      'description': description,
      if (imageUrl != null) 'image': imageUrl,
    });
  }

  Future<void> deleteItem(String id) async {
    await _firestore.collection('items').doc(id).delete();
  }

  Future<String> _uploadImage(File image) async {
    final storageRef =
        _storage.ref().child('items/${DateTime.now().millisecondsSinceEpoch}');
    final uploadTask = storageRef.putFile(image);
    final snapshot = await uploadTask.whenComplete(() => {});
    return await snapshot.ref.getDownloadURL();
  }
}
